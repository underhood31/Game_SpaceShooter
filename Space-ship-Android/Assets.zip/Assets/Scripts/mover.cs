﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mover : MonoBehaviour {
    private Rigidbody laser;
    public float speed;
    private void Start()
    {
        laser = GetComponent<Rigidbody>();
        laser.velocity = transform.forward * speed;
    }
}
