﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player_controller : MonoBehaviour {
    private Rigidbody rb;
    public float speed;
    public float tilt;
    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        speed = 5;
        tilt = 5;
    }
    private void FixedUpdate()
    {

        float horizontalaxis = Input.GetAxis("Horizontal");
        float verticalaxis = Input.GetAxis("Vertical");
        Vector3 coordinates = new Vector3(horizontalaxis, 0.0f, verticalaxis);
        rb.velocity = coordinates * speed;

        rb.position = new Vector3
            (
                Mathf.Clamp(rb.position.x, -5, 5),
                0.0f,
                Mathf.Clamp(rb.position.z, 0, 13.3f));
        rb.rotation = Quaternion.Euler(0.0f, 0.0f, rb.velocity.x * -tilt);



    }

}
    

    // Use this for initialization




